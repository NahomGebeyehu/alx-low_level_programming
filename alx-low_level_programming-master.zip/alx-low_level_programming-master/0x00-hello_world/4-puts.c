#include<stdio.h>

/**
 * main - initial point
 *
 * Return: Return 0
 *
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
