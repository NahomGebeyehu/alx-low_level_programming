#include <stdio.h>
/**
 * main - initial point
 *
 * Return: 0 return
 */
int main(void)
{
	printf("with proper grammar, but the outcome is a piece of art,\n");
	return (0);
}
