#include <stdio.h>

/**
* main - Initial main
*
* Return: 0 return
*/
int main(void)
{
	int digit;

	for (digit = 0; digit < 10; digit++)
	printf("%i", digit);
	putchar('\n');

	return (0);
}
