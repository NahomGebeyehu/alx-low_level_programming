This is a directory for stuying Variables, if, else, while
