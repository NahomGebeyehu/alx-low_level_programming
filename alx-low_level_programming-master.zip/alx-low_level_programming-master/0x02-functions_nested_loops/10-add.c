#include "main.h"

/**
 * add - This function adds two integers
 * @a: This is an int
 * @b: This is an int
 * Return: This returns the sum of a and b
 */
int add(int a, int b)
{
	int c;

	c = a + b;
	return (c);
}
