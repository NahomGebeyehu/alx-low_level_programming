#include "main.h"
/**
 * mul - This multiplies a and b
 * @a: An integer
 * @b: An integer
 * Return: returns result
 */
int mul(int a, int b)
{
	return (a * b);
}
