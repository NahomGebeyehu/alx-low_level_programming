This is a directory for ponters and arrays
