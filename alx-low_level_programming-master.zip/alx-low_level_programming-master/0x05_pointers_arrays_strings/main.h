#ifndef main
void reset_to_98(int *n);
void swap_int(int *a, int *b);
#define main
#endif
