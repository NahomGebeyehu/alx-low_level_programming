This is the directory for more pointers and arrays.
