This a directory for more pointers and arrays and strings.

