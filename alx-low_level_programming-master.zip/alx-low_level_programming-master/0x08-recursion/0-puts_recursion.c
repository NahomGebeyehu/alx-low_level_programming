#include "main.h"
/**
 * _puts_recursion - This function prints a string
 * @s: This is a pointer to char
 * Return: This returns void
 */
void _puts_recursion(char *s)
{
	if (*s != '\0')
	{
		_putchar(*s);
		_puts_recursion(s + 1);
	}
	else
	{
		_putchar('\n');
	}
}
