#include "main.h"
/**
 * _strlen_recursion - This function returns length of a string
 * @s: This is a pointer to string
 * Return: This returns the function itself
 */
int _strlen_recursion(char *s)
{
	if (!*s)
	{
		return (0);
	}
	return (1 + _strlen_recursion(++s));
}
