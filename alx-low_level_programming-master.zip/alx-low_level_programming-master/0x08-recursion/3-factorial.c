#include "main.h"
/**
 * factorial - This returns a factorial of a given number
 * Return: This returns the function its self
 * @n: This is an integer
 */
int factorial(int n)
{

	if (n < 0)
	{
		return (-1);
	}

	if (n == 1)
	{
		return (1);
	}
	return (n * factorial(n - 1));
}
