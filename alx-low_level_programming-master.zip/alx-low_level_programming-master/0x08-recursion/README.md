This is the directory for recursion.
