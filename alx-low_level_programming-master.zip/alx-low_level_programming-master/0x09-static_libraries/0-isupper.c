#include "main.h"
/**
 * _isupper - This function checks for uppercase character
 * @c: This character to be checked
 * Return: This returns 1 if c is uppercase, 0 otherwise
 */
int _isupper(int c)
{
	return (c >= 'A' && c <= 'Z');
}
