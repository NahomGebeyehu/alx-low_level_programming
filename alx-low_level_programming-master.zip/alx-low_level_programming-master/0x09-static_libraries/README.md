This is a directory for Static Libraaries
