#include <stdio.h>
/**
 * main - This is the main to print the program name
 * @argv: These are an array of pointers
 * @argc: These are the number of arguments supplied
 * Return: This returns 0
 */
int main(int __attribute__((__unused__)) argc, char *argv[])
{
	printf("%s\n", argv[0]);

	return (0);
}
