#include <stdio.h>
/**
 * main - This is the main to print the program name
 * @argv: These are an array of pointers
 * @argc: These are the number of arguments supplied
 * Return: This returns 0
 */
int main(int argc, char __attribute__((__unused__)) *argv[])
{
	printf("%d\n", argc - 1);

	return (0);
}
