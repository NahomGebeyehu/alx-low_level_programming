#include <stdio.h>
/**
 * main - This is the main to prints all arguents it recieves
 * @argv: These are an array of pointers
 * @argc: These are the number of arguments supplied
 * Return: This returns 0
 */
int main(int argc, char *argv[])
{
	int arg = 0;

	while (arg < argc)
	{
		printf("%s\n", argv[arg]);
		arg++;
	}

	return (0);
}
