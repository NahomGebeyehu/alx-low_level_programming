#include <stdio.h>
#include <stdlib.h>
/**
 * main - This function prints the multiplicatin of two nos
 * @argv: These are an array of pointers
 * @argc: These are the number of arguments supplied
 * Return: This returns 0 or 1
 */
int main(int argc, char *argv[])
{
	int no1, no2, mul;

	if (argc != 3)
	{
		printf("Error\n");
		return (1);
	}

	no1 = atoi(argv[1]);
	no2 = atoi(argv[2]);
	mul = no1 * no2;

	printf("%d\n", mul);

	return (0);
}
