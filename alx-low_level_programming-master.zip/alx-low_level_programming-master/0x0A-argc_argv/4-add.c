#include <stdlib.h>
#include <stdio.h>
/**
 * main - This functions prints addition of positive numbers
 * @argv: This is an array of pointers
 * @argc: This is the number of arguments
 * Return: This returns 1 or 0
 */
int main(int argc, char *argv[])
{
	int no = 1, digit, sum = 0;

	while (no < argc)
	{
		digit = 0;
		while (argv[no][digit])
		{
		if (argv[no][digit] < '0' || argv[no][digit] > '9')
		{
			printf("Error\n");
			return (1);
		}

			digit++;
		}
			sum += atoi(argv[no]);
			no++;
	}

		printf("%d\n", sum);
		return (0);
}
