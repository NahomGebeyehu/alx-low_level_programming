#include "main.h"
#include <stdlib.h>
/**
 * *create_array - This function creates an array of chars
 * @size: This is size of the array
 * @c: This is a char storage
 * Return: This return a pointer of array
 */
char *create_array(unsigned int size, char c)
{
	char *ch;
	unsigned int i;

	if (size == 0)
	{
		return (NULL);
	}
	ch = malloc(sizeof(c) * size);

	if (ch == NULL)
	{
		return (NULL);
	}

	for (i = 0; i < size; i++)
		cr[i] = c;

	return (ch);
}
