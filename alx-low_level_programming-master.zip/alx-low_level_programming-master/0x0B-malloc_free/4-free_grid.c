#include <stdlib.h>
#include "main.h"
/**
 * free_grid - This function frees a 2D grid
 * @grid: This is a multidimensional array
 * @height: This is the height of grid
 * Return: This returns no return
 */
void free_grid(int **grid, int height)
{
	if (grid != NULL && height != 0)
	{
		for (; height >= 0; height--)
			free(grid[height]);
		free(grid);
	}
}
