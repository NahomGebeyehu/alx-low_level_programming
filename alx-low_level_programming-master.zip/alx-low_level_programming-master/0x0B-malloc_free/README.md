This is a directory for memory allocation.
