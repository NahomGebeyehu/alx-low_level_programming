#include <stdlib.h>
#include "main.h"
/**
 * *malloc_checked - This function allocates memory
 * @b: This is amount of bytes
 * Return: This returns pointer
 */
void *malloc_checked(unsigned int b)
{
	char *c;

	c = malloc(b);
	if (c == NULL)
		exit(98);
	return (c);
}
