#include "main.h"
#include <stdlib.h>
/**
 * *string_nconcat - This function concatenates two strings
 * @s1: THis is the first string
 * @s2: THis is the second string
 * @n: THis is the amount of bytes
 * Return: This returns pointer to the allocated memory
 */
char *string_nconcat(char *s1, char *s2, unsigned int n)
{
	char *out;
	unsigned int ss1, ss2, sout, i;

	if (s1 == NULL)
		s1 = "";

	if (s2 == NULL)
		s2 = "";

	for (ss1 = 0; s1[ss1] != '\0'; ss1++)
		;

	for (ss2 = 0; s2[ss2] != '\0'; ss2++)
		;

	if (n > ss2)
		n = ss2;

	sout = ss1 + n;

	out = malloc(sout + 1);

	if (out == NULL)
		return (NULL);

	for (i = 0; i < sout; i++)
		if (i < ss1)
			out[i] = s1[i];
		else
			out[i] = s2[i - ss1];

	out[i] = '\0';

	return (out);
}
